/* 
 * File:   main.cpp
 * Author: Stewart, Zach
 * Class: 46024
 *
 * Created on July 11, 2014, 6:21 PM
 */


#include <iostream>

using namespace std;

/*
 * 
 */
int main() {

  float f;

  
  for (int c = 0; c <= 20; c++)
  {
    f = (9.0 / 5.0) * c + 32;
    cout << c << "\t" << f << endl;
  }
  return 0;
}

